Build:  pdflatex paper_v1_19_astra ; bibtex paper_v1_19_astra ; pdflatex paper_v1_19_astra ; pdflatex paper_v1_19_astra
Needs in the same folder: mnras.cls, mnras_ci.bst (custom bibliography style), refs.bib, figures/.
paper_v1_19_astra.bbl is included, so the references also appear if bibtex is not run.

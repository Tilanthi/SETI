import sys
p='paper_v1_18.tex'; s=open(p).read()
def R(old,new):
    global s
    n=s.count(old)
    if n!=1: sys.exit(f"MATCH {n}: {old[:80]}")
    s=s.replace(old,new)

# 14,15 abstract
R("A quasar behind $A_V=3$ should be 8 and 17 times brighter than an unobscured quasar, relative to its observed broad H$\\alpha$ and optical continuum. Using JWST/MIRI imaging of 49 spectroscopically confirmed LRDs, 43 of which have a measured broad H$\\alpha$ line, including non-detections, we measure both ratios and compare with SDSS quasars.",
  "A quasar behind $A_V=3$ should be 8 and 17 times brighter at rest-frame 3\\,$\\mu$m than an unobscured quasar, relative to its observed broad H$\\alpha$ and optical continuum. Using JWST/MIRI imaging of 49 spectroscopically confirmed LRDs (43 with a measured broad H$\\alpha$ line), and using every MIRI flux including non-detections, we measure both ratios and compare them with SDSS quasars.")

# 6 Barro
R("Our stellar fluxes agree with the MAST pipeline aperture-corrected totals to 7--8 per cent (Section~\\ref{sec:phot}), so the offset most likely arises in their aperture corrections; adopting their scale would lower every $K$ limit by a factor of 1.6. The origin of the offset is not established; we retain our scale because it is the conservative choice.",
  "Adopting their scale would lower every $K$ limit by a factor of 1.6. The origin of the offset is not established; our stellar fluxes agree with the MAST aperture-corrected totals to 7--8 per cent (Section~\\ref{sec:phot}), and we retain our scale because it is the conservative choice.")
# 7 Leung
R("by factors of 2.4, 2.0 and 1.04 ($1.7$--$2.1\\sigma$).",
  "by factors of 2.4, 2.0 and 1.04 (our measurements exceed their limits at 1.7--2.1 times our blank-sky $\\sigma$).")
# 5 redshifts
R("The spectroscopic redshifts replace the parent-catalogue value for seven objects (Appendix~\\ref{app:method}). The six further RUBIES objects take theirs from their RUBIES NIRSpec spectra \\citep{hviding25}.",
  "Spectroscopic redshifts replace the parent-catalogue value for seven objects: PRIMER-UDS159206 and 33774 (Section~\\ref{sec:ha}) and five of the six RUBIES-only objects (Appendix~\\ref{app:method}), which take theirs from their RUBIES NIRSpec spectra \\citep{hviding25}. The sixth RUBIES object, 23054, already carries its RUBIES value.")

# 2, 19, 20a: photometry section
old_start="The response is calibrated on 52 isolated point sources found in the science mosaics themselves."
old_end="Bands other than these enter only Appendix~\\ref{app:resid}."
i=s.index(old_start); j=s.index(old_end)+len(old_end)
new_phot=("The response is calibrated on isolated point sources in the science mosaics themselves (26 in F1800W and four in F2100W), whose fluxes agree with the aperture-corrected totals of the MAST pipeline source catalogues to 7--8 per cent. "
"In F1800W each response comes from the object's own field where that field contributes at least five calibration stars (COSMOS, UDS), and from the 26-star band pool otherwise. In F2100W no field has five stars, so the four-star pool is used for the 17 broad-line objects in the pool's fields, and STPSF \\citep{perrin14} for the one Abell 2744 object. Bands without calibration stars (F1280W, F1500W, F2550W) always use STPSF. "
"Each test uses the MIRI band whose rest wavelength falls nearest 3\\,$\\mu$m: the H$\\alpha$ test among the two long bands F1800W and F2100W, the continuum test among all of the object's measured bands. For 42 of the 222 continuum objects (11 of the 49 confirmed LRDs) the band nearest rest 3\\,$\\mu$m is F1280W, F1500W or F2550W; these eleven confirmed LRDs, all among the 43 broad-line LRDs, therefore enter the continuum test in a different band from the H$\\alpha$ test, with an STPSF response. "
"Objects whose responses come from stacks of at least five stars (25 broad-line and 22 confirmed LRDs) form the subsample used in Section~\\ref{sec:robust}. Bands other than these enter only Appendix~\\ref{app:resid}. The stellar profiles, response uncertainties and recovery tests are described in Appendix~\\ref{app:response}.")
s=s[:i]+new_phot+s[j:]

# 16
R("have a best-fitting median $K=0.94$ with the same median slit correction applied, though they constrain it only weakly.",
  "have a best-fitting median $K=0.94$ with the same median slit correction applied, although the 22 objects constrain the control median only weakly.")
# 18
R("unless $\\eta$ is below about 0.24.","unless $\\eta$ is below about 0.23--0.24.")
# 17
R("tightens the whole-population median limit by 23 per cent (Table~\\ref{tab:robust}, note $e$). The matched screened prediction falls to a median of 4.6,",
  "tightens the whole-population median limit by 23 per cent, to about 1.4 (Table~\\ref{tab:robust}, note $e$). The matched screened prediction falls to a median of 4.6,")
# 9 SMC
R("Per-object screened predictions from the \\citet{gordon23} and \\citet{fitzpatrick19} laws change the continuum free-width $q_3$ by $-19$ to $+5$ per cent; the template shape changes it by at most 0.6 per cent.",
  "Per-object screened predictions from the \\citet{gordon23} and \\citet{fitzpatrick19} laws change the continuum free-width $q_3$ by $-19$ to $+5$ per cent; the template shape changes it by at most 0.6 per cent. These three are Milky Way laws; for the SMC Bar curve of \\citet{gordon03}, often adopted for reddened quasars, a screen of $A_V=3$ gives $K=7.3$ and $K_P=17.8$ at rest 3\\,$\\mu$m, within the range of the per-object values above, and the equivalent extinctions become $A_V\\le0.88$ and $\\le1.46$. The conclusions are unchanged.")
# 20b
R("Upper limits are taken at a threshold $-2\\Delta\\ln\\mathcal{L}=t^*$ chosen by simulation",
  "Because the blank-sky noise is heavy-tailed, we set the likelihood threshold for each limit by simulation so that the quoted 97.5 per cent limits are honest, and we checked the six headline limits on independent simulations. Upper limits are taken at a threshold $-2\\Delta\\ln\\mathcal{L}=t^*$ chosen by simulation")

# Appendix response: add moved details
R("\\label{app:response}\n\n",
  "\\label{app:response}\n\n"
  "\\emph{Calibration stars.} The response is calibrated on 52 isolated point sources found in the science mosaics. After rejecting two outliers, 50 remain: 26 in F1800W, four in F2100W and 20 in F770W. Each stellar profile is background-subtracted with the same annulus as the targets and normalised to its flux within 10\\,arcsec; STPSF puts only 0.1--0.4 per cent of the flux beyond that radius. As an independent check of the flux scale, the stars' fluxes agree with the aperture-corrected totals in the MAST pipeline source catalogues to a median of 7 per cent in F1800W (23 stars) and 8 per cent in F2100W (four stars). Resampling the stars gives a shared fractional uncertainty in $r$ of 16 per cent in F1800W, dominated by the seven-star UDS stack, and 4 per cent in F2100W. With only four stars this bootstrap estimate is itself uncertain; the 8 per cent cross-profile spread, included as a shared nuisance (below), is the more realistic bound. Because the injected profile is normalised by its own sum, the overall normalisation cancels in $r$, but the profile shape does not. A recovery grid of injected sources shows a median bias of $-0.1$ per cent.\n\n"
  "\\emph{Response assignment.} ")

# 20c: split results table
old_tab_start="\\begin{tabular}{@{}llcccccc@{}}"
k=s.index(old_tab_start); kend=s.index("\\end{table*}",k)
new_main=r"""\begin{tabular}{@{}llcccccc@{}}
\toprule
sample & ratio & $N$ & best-fit $K_{\rm med}$ & limit on $K_{\rm med}$ & limit on $m$ & $q_3$ & $q_2$\\
\midrule
broad-line LRDs & infrared-to-H$\alpha$ ($K$) & 43$^a$ & 0.31 & 1.70 val. & 1.79 val. & 0.29 val. & --$^b$\\
confirmed LRDs & infrared-to-optical ($K_P$) & 49$^a$ & 1.15 & -- & 4.07 val. & -- & 0.45 val.\\
 & (free width) & & & 2.73 & & 0.14 val. & \\
\bottomrule
\end{tabular}

\smallskip
$^a$ Includes three provisional broad-line objects (Section~\ref{sec:samples}); excluding them changes the H$\alpha$ limits by $<$2 per cent. They are also among the 49 confirmed LRDs; their effect on the continuum limits was not separately evaluated. $^b$ Not calibrated for the H$\alpha$ test: the H$\alpha$ calibration covers $K_{\rm med}$, $m$ and $q_3$ only.
"""
s=s[:k]+new_main+s[kend:]
R("\\caption{Principal results: 97.5 per cent upper limits.",
  "\\caption{Principal results: 97.5 per cent upper limits for the headline samples; further samples and variants are in Table~\\ref{tab:results_extra}.")
extra=r"""
\emph{Further limits.} Table~\ref{tab:results_extra} gives the limits for the other samples and variants discussed in Section~\ref{sec:results}; all are calibrated but not independently validated.

\begin{table*}
\caption{Further 97.5 per cent upper limits (calibrated only), for the samples and variants not in Table~\ref{tab:results}. Columns as in Table~\ref{tab:results}.}
\label{tab:results_extra}
\scriptsize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{@{}llcccccc@{}}
\toprule
sample & ratio & $N$ & best-fit $K_{\rm med}$ & limit on $K_{\rm med}$ & limit on $m$ & $q_3$ & $q_2$\\
\midrule
broad-line LRDs & infrared-to-H$\alpha$ ($K$), free width & 43 & & 0.86 & & & \\
own-fit sample & infrared-to-H$\alpha$ ($K$) & 32 & 0.50 & 3.20 & 2.78$^a$ & 0.35 & --$^b$\\
broad-line LRDs & infrared-to-optical ($K_P$) & 43 & 1.31 & -- & 3.68$^c$ & 0.29 & 0.44\\
all candidates & infrared-to-optical ($K_P$) & 222 & 0.62 & -- & -- & -- & 0.16\\
 & (free width) & & & 1.04 & & & \\
line-free subset & infrared-to-optical ($K_P$) & 100 & 0.62 & -- & -- & 0.20 & 0.09$^d$\\
\bottomrule
\end{tabular}

\smallskip
$^a$ Lower than the main-component limit because the calibrated thresholds differ ($t^*=18$ for $m$, $25$ for $K_{\rm med}$; Table~\ref{tab:calib}). $^b$ Not calibrated for the H$\alpha$ test: the H$\alpha$ calibration covers $K_{\rm med}$, $m$ and $q_3$ only. $^c$ Calibrated only ($t^*=18$); indicative. $^d$ $q_3$ exceeds $q_2$ only because its calibrated threshold is higher (25 versus 4.65); it is not a stronger constraint at $A_V=2$.
\end{table*}
"""
R("\\begin{table}\n\\caption{Thresholds and worst-cell coverage.", extra.lstrip("\n")+"\n\\begin{table}\n\\caption{Thresholds and worst-cell coverage.")
# text refs to old footnotes
R("(Table~\\ref{tab:results}, note $f$)","(Table~\\ref{tab:results_extra}, note $c$)")
R("(Table~\\ref{tab:results}, note $d$)","(Table~\\ref{tab:results_extra}, note $d$)")
R("Fig.~\\ref{fig:flux} shows the measured fluxes and Table~\\ref{tab:results} the limits.",
  "Fig.~\\ref{fig:flux} shows the measured fluxes and Table~\\ref{tab:results} the limits (other samples and variants in Table~\\ref{tab:results_extra}, Appendix~\\ref{app:calib}).")
R("The other limits in Table~\\ref{tab:results} are calibrated but not independently validated.",
  "The other limits in Tables~\\ref{tab:results} and \\ref{tab:results_extra} are calibrated but not independently validated.")
R("These quantities are omitted from Table~\\ref{tab:results}.","These quantities are omitted from Tables~\\ref{tab:results} and \\ref{tab:results_extra}.")

# 11 acknowledgements
R("Filter curves are from the SVO Filter Profile Service.",
  "Filter curves are from the SVO Filter Profile Service. "
  "This work is based on observations made with the NASA/ESA/CSA James Webb Space Telescope. The data were obtained from the Mikulski Archive for Space Telescopes at the Space Telescope Science Institute, which is operated by the Association of Universities for Research in Astronomy, Inc., under NASA contract NAS 5-03127 for JWST. "
  "Some of the data products presented herein were retrieved from the Dawn JWST Archive (DJA). DJA is an initiative of the Cosmic Dawn Center (DAWN), which is funded by the Danish National Research Foundation under grant DNRF140. "
  "Funding for the Sloan Digital Sky Survey IV has been provided by the Alfred P. Sloan Foundation, the U.S. Department of Energy Office of Science, and the Participating Institutions. SDSS-IV is managed by the Astrophysical Research Consortium for the Participating Institutions of the SDSS Collaboration. "
  "This publication makes use of data products from the Wide-field Infrared Survey Explorer, which is a joint project of the University of California, Los Angeles, and the Jet Propulsion Laboratory/California Institute of Technology, funded by the National Aeronautics and Space Administration. "
  "This research has made use of the NASA/IPAC Infrared Science Archive, which is funded by the National Aeronautics and Space Administration and operated by the California Institute of Technology.")
# 12 address
R("$^{1}$RAL Space, Rutherford Appleton Laboratory, UK}",
  "$^{1}$RAL Space, STFC Rutherford Appleton Laboratory, Harwell Campus, Didcot, Oxfordshire OX11 0QX, UK}")
open(p,'w').write(s); print("ok")

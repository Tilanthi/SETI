# Suggested changes v1.18 -> v1_19_astra (ASTRA PA, 2026-11-11)

Each change below is an exact replacement; nothing else in the file was touched. Items marked AUTHOR CHECK depend on how a number was computed.

## 1. CCM89 R_V=3.1 at 3.0 um gives 0.2996 (K=7.92); 0.298 corresponds to ~2.9 um
- old: `\simeq10^{0.298A_V},`
- new: `\simeq10^{0.300A_V},`

## 2. screen values at 3.0 um
- old: `law ($R_V=3.1$) at 3\,$\mu$m: $K=7.8$ and $K_P=17$ at $A_V=3$, and 3.9 and 6.6 at $A_V=2$.`
- new: `law ($R_V=3.1$) at 3\,$\mu$m: $K=7.9$ and $K_P=17$ at $A_V=3$, and 4.0 and 6.6 at $A_V=2$.`

## 3. Table 1 caption
- old: `Screen predictions at $A_V=3$ and 2: $K=7.8$ and 3.9; $K_P=17$ and 6.6.}`
- new: `Screen predictions at $A_V=3$ and 2: $K=7.9$ and 4.0; $K_P=17$ and 6.6.}`

## 4. Sect 4.1
- old: `A quasar behind $A_V=3$ would have $K=7.8$, and one behind $A_V=2$ $K=3.9$:`
- new: `A quasar behind $A_V=3$ would have $K=7.9$, and one behind $A_V=2$ $K=4.0$:`

## 5. Conclusions (i)
- old: `would instead give factors of 7.8 and 17.`
- new: `would instead give factors of 7.9 and 17.`

## 6. log10(1.79)/0.2996=0.84; log10(4.1)/0.2996=2.05 (AUTHOR CHECK: if these were per-object values, revert)
- old: `The equivalent extinction is $A_V\le0.85$ in the primary analysis, and up to $A_V\approx2.1$ in that`
- new: `The equivalent extinction is $A_V\le0.84$ in the primary analysis, and up to $A_V\approx2.0$ in that`

## 7. abstract, same recomputation (AUTHOR CHECK)
- old: `$A_V\lesssim0.85$--1.5 ($\lesssim2.1$ when`
- new: `$A_V\lesssim0.84$--1.5 ($\lesssim2.0$ when`

## 8. conclusions (iii)(a) (AUTHOR CHECK)
- old: `The equivalent screen extinction is $A_V\lesssim0.85$ from`
- new: `The equivalent screen extinction is $A_V\lesssim0.84$ from`

## 9. 1.79/3.97=0.451
- old: `$\eta_Q>0.46$`
- new: `$\eta_Q>0.45$`

## 10. Gordon+03 SMC Bar at exactly 3.0 um gives 7.42/18.12 (7.3/17.8 is the value at 2.8 um)
- old: `a screen of $A_V=3$ gives $K=7.3$ and $K_P=17.8$ at rest 3\,$\mu$m,`
- new: `a screen of $A_V=3$ gives $K=7.4$ and $K_P=18.1$ at rest 3\,$\mu$m,`

## 11. recomputed with SMC 3.0 um coefficients (AUTHOR CHECK)
- old: `the equivalent extinctions become $A_V\le0.88$ and $\le1.46$.`
- new: `the equivalent extinctions become $A_V\le0.87$ and $\le1.45$.`

## 12. the 1.79->1.22 trend reproduces only without the W3 cut
- old: `The reference ratios depend on luminosity. $Q$ falls from $\log Q=1.79$ to 1.22 across $\log L({\rm H}\alpha)=41.3$--44.1,`
- new: `The reference ratios depend on luminosity. Among quasars with W1 and W2 detections, $Q$ falls from $\log Q=1.79$ to 1.22 across $\log L({\rm H}\alpha)=41.3$--44.1 (with the W3 requirement of the $Q$ reference the faint end is 1.90),`

## 13. duplicate footnote mark
- old: `quasar template shape (6)$^e$`
- new: `quasar template shape (6)$^f$`

## 14. duplicate footnote mark
- old: `$^e$ Six filter-integrated shape variants`
- new: `$^f$ Six filter-integrated shape variants`

## 15. soften: nature of Euclid candidates uncertain
- old: `where they appear to be a minor part of the quasar population \citep{euclidbisigello26},`
- new: `where, if they are active nuclei, they are a minor part of the quasar population \citep{euclidbisigello26}; whether these photometric candidates share the physics of the high-redshift LRDs is not yet established,`

## 16. intro: same caution
- old: `photometric candidates have now also been found down to $z\approx0.3$ in Euclid imaging \citep{euclidbisigello26}.`
- new: `photometric candidates have now also been reported down to $z\approx0.3$ in Euclid imaging \citep{euclidbisigello26}, although their relation to the JWST population remains to be established.`

## 17. OPTIONAL: sets up the Euclid/WISE extension
- old: `Spectroscopic and mid-infrared follow-up of the brightest would allow the same test closer to us.`
- new: `Spectroscopic and mid-infrared follow-up of the brightest would allow the same test closer to us; over wide areas, WISE photometry is deep enough to apply the continuum test to such candidates.`


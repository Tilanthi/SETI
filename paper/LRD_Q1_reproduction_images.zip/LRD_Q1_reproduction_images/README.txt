Euclid Q1 "Little Red Dots" reproduction (Bisigello et al. 2025, A&A 711 A24, arXiv:2503.15323)
Images produced by ASTRA PA, 2026-11-03/04, as a dry run for Euclid DR1 (Project 5).
figs/       final figures; *_compare.png = this work (left/top) vs published (right/bottom)
            fig01 bands, fig02 cutouts (+galleries), fig03 SED fits, fig04 MUV-z, fig06/07 LFs (WP4),
            wp5_fig06_07_lf_compare = reconciled LF (own-field Vmax), fig09 z-recovery mocks, fig10 z hist,
            fig11 mag hists, wp2/ = IRAC vs Cosmic Dawn (paper Fig. 8), WP4a_* = cutout tests
wp3_mocks/  mock z-recovery with and without IGM (Lyman-alpha) treatment
cluster/    further images from the cluster run (out/figs, cutout renders)
Reports: /workspace/LRD/reports/WP1..WP5 (not included).

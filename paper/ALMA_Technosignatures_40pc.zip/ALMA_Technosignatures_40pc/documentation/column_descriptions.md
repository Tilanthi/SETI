# Column descriptions

Every table in this archive is described here: what each file holds, how it joins the others, and what every column means and is measured in. The descriptions and the files are generated together from one specification, so a documented column that the file does not have, or a column the documentation does not mention, is not possible.

A blank unit means the quantity is a count, a flag, a name or a ratio. A flag is written 1 or 0 and never as a word. An empty field means the value does not apply or is withheld, and never zero; each file header says which.

## `catalogues/spectral_windows.csv`

1663 rows, 45 columns.

One row per searched spectral window: the window-level measurement every count in the article is formed from.

A window is identified by its target identifier, its execution block and its frequency edges; those four fields are unique over the table.

Two readings of the trigger are given. The adopted statistic is read over the whole primary beam (trigger_whole_beam) and is the one the crossing table is built on; trigger_narrow_field is the same statistic read over the narrower extraction field, which drops the integrations whose pointing falls outside it. They differ on six rows, which trigger_flags_agree selects without recomputation.

An empty field is a value that does not apply, never a zero: the control terms are measured on the fine-channel windows and are empty on the coarse ones.

**Joins.** star joins stellar_sample.csv; eb joins execution_blocks.csv; (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins the sensitivity tables and control_field_statistics.csv -- all four fields, because two positions can share one window of one block, and (eb, nu_lo_GHz, nu_hi_GHz) alone is duplicated here; a crossing is tied to its window by frequency CONTAINMENT in (nu_lo_GHz, nu_hi_GHz), not by equality with crossing_nu_topo_GHz.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation, as used throughout the article and in every file here |
| `system` | -- | system identifier; the components of a bound pair share it |
| `target_id` | -- | identifier the window was extracted under, which distinguishes the components of a pair observed in one execution block |
| `ra_deg` | deg | right ascension of the extraction position, ICRS |
| `dec_deg` | deg | declination of the extraction position, ICRS |
| `eb` | -- | ALMA execution block (ASDM) identifier; with the project code this retrieves the original data from the ALMA Science Archive |
| `project_code` | -- | ALMA project code, cited as ADS/JAO.ALMA# followed by this value |
| `date_utc` | date | UTC date of the execution block |
| `t_start_mjd` | d | adopted start epoch of the execution block, MJD |
| `band` | -- | ALMA receiver band |
| `nu_lo_GHz` | GHz | lower edge of the spectral window, topocentric as delivered |
| `nu_hi_GHz` | GHz | upper edge of the spectral window, topocentric as delivered |
| `chan_width_Hz` | Hz | delivered channel width |
| `on_source_s` | s | on-source integration time at this position |
| `n_int` | -- | integrations retained at this position |
| `rms_mJy` | mJy | per-channel noise at the extraction position |
| `smin_mJy` | mJy | amplitude limit at the trigger, five times the noise divided by the primary-beam response |
| `theta_pb_arcsec` | arcsec | primary-beam FWHM, 1.22 lambda / D, of the annulus this window was searched with |
| `array` | -- | 12m or 7m: the array that observed the window, from the archive |
| `geometry_provenance` | -- | corrected-geometry where the window was extracted with the dish read from the data; frozen-geometry where it predates that repair and its annulus assumed a 12 m dish |
| `pb_offset_arcsec` | arcsec | angular offset of the star from the phase centre |
| `pb_atten` | -- | primary-beam response at the star, between 0 and 1 |
| `dist_pc` | pc | distance adopted for the star |
| `search_class` | -- | A where the window resolves a carrier in one channel, B where the channel is coarse |
| `drift_max_Hz_s` | Hz/s | largest drift rate searched in this window |
| `a_max_m_s2` | m/s2 | line-of-sight acceleration that corresponds to it |
| `n_drift_trials` | -- | drift trials searched |
| `n_search_cells` | -- | search cells in this window, channels times drift trials |
| `n_ind_cells` | -- | independent cells after the correlation between neighbouring drift trials is accounted for |
| `eirp_p90_W` | W | adopted 90 per cent completeness EIRP limit; the smearing retention divided out is the one measured on the delivered channel response, not the transform-limited form |
| `eirp_p90_lo_W` | W | lower end of its interval: the dispersion measured between the directly injected windows, the same pair of factors on every row, and not a bound measured in this window's own band and channelisation |
| `eirp_p90_hi_W` | W | upper end of that interval, on the same basis |
| `completeness_basis` | -- | injected where this window carries its own injection ladder, transferred where its completeness comes from the calibration of completeness_calibration.csv |
| `T_star_narrow_field` | -- | de-drifted search statistic at the stellar position, read over the narrower extraction field |
| `T_ctrl_max_narrow_field` | -- | largest statistic among the window control positions, same field |
| `n_ctrl` | -- | control positions in this window ensemble |
| `n_ctrl_trig` | -- | how many of them reach the trigger |
| `mask_attr_share` | -- | share of those control exceedances the attribution mask takes, in the star rest frame |
| `unmasked_fraction` | -- | fraction of this window channels lying OUTSIDE the attribution mask, evaluated in the star own rest frame. The survey constrains nothing inside the mask, so a window at 0 carries no limit and is not in any distribution of limits in the article; blank where a velocity term is missing and the value would depend on it |
| `telluric_factor` | -- | factor by which the remaining exceedances are reduced by the atmospheric screen, applied to the crossings on the same radius and in the same topocentric frame |
| `trigger_whole_beam` | -- | 1 where this window holds a threshold crossing under the adopted whole-beam statistic |
| `trigger_narrow_field` | -- | 1 where it holds one under the narrower extraction field |
| `trigger_flags_agree` | -- | 1 where the two readings agree, 0 on the nine rows where they do not |
| `crossing_nu_topo_GHz` | GHz | frequency of the adopted crossing this window holds, empty where it holds none; it can differ from the narrower field's own peak in the same window |
| `disposition` | -- | disposition carried in the crossing table, where there is one |

## `catalogues/stellar_sample.csv`

90 rows, 19 columns.

One row per searched target identifier: the sample the survey was carried out on, with what was searched toward each position.

There are 90 identifiers over 87 designations and 83 systems; the difference is the components of bound pairs, which share a designation and sometimes a system but were extracted at their own positions. The article count of searched stars is a count of these identifiers.

Two archival-tail execution blocks lie outside the window extent of this deposit; the two crossings they hold are in threshold_crossings.csv and are not counted in the per-star window totals here.

**Joins.** target_id joins spectral_windows.csv and the sensitivity tables; star joins threshold_crossings.csv and recurrence_tests.csv.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation, as used throughout the article |
| `system` | -- | system identifier; the components of a bound pair share it |
| `target_id` | -- | identifier the windows were extracted under; unique over this table |
| `ra_deg` | deg | right ascension of the extraction position, ICRS |
| `dec_deg` | deg | declination of the extraction position, ICRS |
| `dist_pc` | pc | distance adopted for the star |
| `n_blocks` | -- | execution blocks searched toward this position |
| `n_windows` | -- | spectral windows searched toward it |
| `n_windows_class_A` | -- | of those, windows that resolve a carrier in one channel |
| `n_windows_class_B` | -- | of those, windows with a coarse channel |
| `bands` | -- | ALMA receiver bands with at least one searched window, joined by + |
| `nu_min_GHz` | GHz | lowest window edge searched toward this position |
| `nu_max_GHz` | GHz | highest window edge searched toward it |
| `on_source_h` | h | summed on-source time over its windows; windows of one block overlap in time, so this is a window total and not an observing duration |
| `eirp_p90_min_W` | W | deepest 90 per cent completeness EIRP limit among its windows |
| `eirp_p90_median_W` | W | median of that limit over its windows |
| `n_crossings_whole_beam` | -- | threshold crossings in its windows under the adopted whole-beam statistic |
| `n_crossings_narrow_field` | -- | the same count under the narrower extraction field |
| `project_codes` | -- | ALMA project codes its blocks belong to, joined by + |

## `catalogues/execution_blocks.csv`

409 rows, 18 columns.

One row per execution block of the primary census: the archival accounting that ties every searched window to a retrievable observation.

The block identifier and the project code together retrieve the original data from the ALMA Science Archive, where the project code is cited as ADS/JAO.ALMA# followed by its value.

epoch_source records where the epoch was read: block means the block's own recorded start, and any other value means it was resolved through the member observing unit instead.

Two rows are archival-tail blocks. Each holds a threshold crossing and lies outside the window extent of this archive, so every window column of theirs is empty and their project code is not resolved here; the block identifier alone retrieves them from the archive. They are present so that every crossing names a block this table has.

The block sets outside these two -- the reserved hold-out, the archival extension, the out-of-sample control beyond 40 pc, and the blocks that were not searched and why -- are accounted for in the article's own block ledger, which this table does not duplicate.

**Joins.** eb joins spectral_windows.csv, threshold_crossings.csv and recurrence_tests.csv.

| column | unit | description |
|---|---|---|
| `eb` | -- | ALMA execution block (ASDM) identifier |
| `project_code` | -- | ALMA project code; cite as ADS/JAO.ALMA# followed by this value |
| `date_utc` | date | UTC date of the block |
| `epoch_mjd` | d | adopted start epoch, MJD |
| `epoch_source` | -- | block where the epoch is the block's own recorded start, otherwise the route by which it was resolved |
| `bands` | -- | ALMA receiver bands searched in this block, joined by + |
| `n_targets` | -- | target identifiers searched in it |
| `targets` | -- | their star designations, joined by + |
| `n_windows` | -- | spectral windows searched in it |
| `n_windows_class_A` | -- | of those, fine-channel windows |
| `n_windows_class_B` | -- | of those, coarse-channel windows |
| `nu_min_GHz` | GHz | lowest window edge searched in it |
| `nu_max_GHz` | GHz | highest window edge searched in it |
| `on_source_h` | h | largest on-source time among its windows, which is the block's own on-source duration at that position |
| `theta_pb_median_arcsec` | arcsec | median recorded primary-beam FWHM of its windows; the compact array is identifiable by it |
| `n_crossings_whole_beam` | -- | threshold crossings in it under the adopted whole-beam statistic |
| `n_crossings_narrow_field` | -- | the same count under the narrower extraction field |
| `set_name` | -- | the block set this row belongs to: primary census, or archival tail for the two blocks that lie outside the window extent of this archive |

## `catalogues/frequency_coverage.csv`

46 rows, 14 columns.

One row per contiguous island of searched frequency: the union the windows cover, with what was searched in each part of it.

Islands are formed by merging the topocentric edges of all searched windows, so the widths here sum to the searched union and not to the sum of the window widths, which double-counts the frequencies two blocks share.

masked_GHz is the width inside the island covered by the attribution mask, computed as the adopted half-width about every transition of molecular_line_matches.csv WITH in_mask = 1, which is every row of that file: the mask is the whole query, one rule for every species. The survey constrains nothing inside the masked width.

**Joins.** nu_lo_GHz and nu_hi_GHz bracket the windows of spectral_windows.csv that fall in the island; the transitions are those of molecular_line_matches.csv with in_mask = 1 and a rest frequency inside it.

| column | unit | description |
|---|---|---|
| `island` | -- | island number, ordered by frequency |
| `nu_lo_GHz` | GHz | lower edge of the island, topocentric |
| `nu_hi_GHz` | GHz | upper edge of the island, topocentric |
| `width_GHz` | GHz | its width |
| `bands` | -- | ALMA receiver bands contributing to it, joined by + |
| `n_windows` | -- | searched windows lying inside it |
| `n_windows_class_A` | -- | of those, fine-channel windows |
| `n_windows_class_B` | -- | of those, coarse-channel windows |
| `n_targets` | -- | target identifiers with a window inside it |
| `n_blocks` | -- | execution blocks with a window inside it |
| `masked_GHz` | GHz | width inside the island covered by the attribution mask |
| `masked_fraction` | -- | that width as a fraction of the island width |
| `n_masked_transitions` | -- | transitions of the MASK (molecular_line_matches.csv with in_mask = 1) whose rest frequency lies inside it |
| `n_crossings_whole_beam` | -- | threshold crossings inside it under the adopted statistic |

## `candidates/threshold_crossings.csv`

51 rows, 43 columns.

One row per threshold crossing: every cell in the survey whose de-drifted search statistic reached the trigger at a stellar position, under the adopted whole-beam statistic.

trigger_whole_beam is 1 on every row by construction, because this is the adopted set; trigger_narrow_field records whether the same window also holds a crossing under the narrower extraction field, and it is 0 on two rows. Four further windows hold a narrow-field crossing and no adopted one; they are in spectral_windows.csv with trigger_flags_agree = 0.

atmospheric_flag marks the one crossing the atmospheric screen removes from both sides of the chance comparison. It is a crossing, it is unattributed, and it is tested for recurrence; what the flag records is that it is excluded from the comparison with chance, because the control side is screened on the same radius in the same topocentric frame.

masked_transition and masked_dv_kms give the nearest transition of the attribution mask in the star rest frame. nearest_transition gives the nearest catalogued transition of any species in the wider query, which is a different quantity: a crossing can be far from any masked line and close to an unmasked one.

An empty field is a value withheld, not a zero.

**Joins.** star_in_sample joins stellar_sample.csv; (eb, nu_topo_GHz) is unique and joins recurrence_tests.csv; the window is the row of spectral_windows.csv with the same eb whose edges CONTAIN nu_topo_GHz -- two crossings lie at a frequency the narrower field never reported in the same window, so a join on a frequency column finds neither; two further crossings lie in archival-tail blocks outside the window catalogue and carry in_window_catalogue = 0.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation of the position the crossing was found at |
| `star_in_sample` | -- | designation under which the sample table counts that position; it differs from star for the one component whose extractions are second readings of windows the sample counts under its primary |
| `eb` | -- | ALMA execution block (ASDM) identifier of the discovery block |
| `project_code` | -- | its ALMA project code, empty for the two archival-tail blocks; cite as ADS/JAO.ALMA# followed by this value |
| `date_utc` | date | UTC date of that block |
| `band` | -- | ALMA receiver band |
| `nu_topo_GHz` | GHz | crossing frequency as delivered by the correlator |
| `nu_star_GHz` | GHz | the same frequency in the star rest frame: nu_topo_GHz x (1 - v_bary_kms/c) x (1 + v_sys_kms/c), c = 299792.458 km/s |
| `v_bary_kms` | km/s | topocentric-to-barycentric velocity term of the discovery block at its own pointing and mid-time, as used in nu_star_GHz |
| `v_sys_kms` | km/s | systemic velocity of the star, as used in nu_star_GHz |
| `window_nu_lo_GHz` | GHz | lower edge of the window that holds it, empty for the archival-tail crossings |
| `window_nu_hi_GHz` | GHz | upper edge of that window |
| `search_class` | -- | class of the search that found the crossing, A fine or B coarse; for the two crossings in archival-tail blocks, whose host window is outside the extent of spectral_windows.csv, it is the class of the fine-channel search they were found in, so a query on this column returns every Class A crossing the article reports |
| `in_window_catalogue` | -- | 1 where the host window is in spectral_windows.csv, 0 for the two crossings in archival-tail blocks outside its extent |
| `T_star` | -- | de-drifted search statistic at the stellar position, the quantity of Eq. 1 |
| `T_ctrl_max` | -- | largest statistic among that window control positions |
| `rms_mJy` | mJy | per-channel noise of the host window at the extraction position |
| `eirp_p90_W` | W | that window 90 per cent completeness EIRP limit |
| `masked_transition` | -- | nearest transition of the attribution mask in the star rest frame |
| `masked_dv_kms` | km/s | stellar-frame offset from it, positive where the crossing lies above the transition in frequency |
| `mask_coincident_not_attributed` | -- | 1 where the crossing lies inside the mask and is not attributed |
| `attributed` | -- | 1 where the crossing is attributed to a catalogued transition |
| `nearest_transition` | -- | species of the nearest catalogued transition of any species, from the wider catalogue query; empty where the query is not deposited |
| `nearest_transition_qn` | -- | its quantum numbers as the catalogue gives them |
| `nearest_transition_GHz` | GHz | its rest frequency |
| `nearest_transition_dv_kms` | km/s | stellar-frame offset of the crossing from it |
| `nearest_transition_catalogue` | -- | the line catalogue the entry was taken from |
| `atmospheric_flag` | -- | 1 on the crossing the atmospheric screen removes from both sides of the chance comparison; it remains a crossing and remains unattributed |
| `atmospheric_species` | -- | the atmospheric species responsible |
| `atmospheric_line_GHz` | GHz | its transition frequency, topocentric |
| `atmospheric_offset_MHz` | MHz | offset of the crossing from it, inside the screening radius |
| `trigger_whole_beam` | -- | 1 on every row: this table is the adopted whole-beam set |
| `trigger_narrow_field` | -- | 1 where the host window also holds a crossing under the narrower extraction field |
| `quality_flagged` | -- | 1 where the host window is data-quality flagged |
| `n_rep` | -- | covering repeat execution blocks |
| `dt_min_d` | d | shortest interval to a covering repeat |
| `dt_max_d` | d | longest interval to a covering repeat |
| `dt_from_unit_stamp` | -- | 1 where an interval is measured from the observing unit stamp rather than from the blocks' own |
| `T_pers` | -- | statistic a carrier persisting at the discovery flux would give at the predicted cell |
| `T_rep` | -- | statistic measured at that cell at the carried drift |
| `T_rep_is_upper_bound` | -- | 1 where T_rep is a window maximum and so bounds the cell from above |
| `sigma_excl` | -- | depth at which an emitter at rest in the stellar frame at the discovery flux (a line-like source) is excluded at the predicted cell; it does not test a drifting or re-tuned carrier |
| `disposition` | -- | disposition carried in the article's own crossing ledger: attributed (a catalogued transition inside the mask, no repeat reading); attributed; recurs / attributed; not recovered (the line is or is not found again in a separated-session repeat block); attributed; flagged and unattributed; flagged (in the block that fails the data-quality criterion); unattributed; no recurrence (read at its separated-session repeat blocks, nothing at the trigger); unattributed; not read (repeat coverage exists but was not read); unattributed; no separated repeat (code US: every repeat block is of the discovery's own session, so the recurrence test, which reads separated sessions only, has none) |

## `candidates/molecular_line_matches.csv`

111 rows, 16 columns.

One row per transition of the dated catalogue QUERY, which is the attribution mask: every species these setups cover that is detected in discs or molecular clouds, one rule for all of them, so in_mask is 1 on every row (the column is kept so that a reader can see that no species is left out).

The query is every transition of the named species that falls inside a searched island below the adopted upper-state energy cut, together with the hydrogen recombination series, taken from one query of the catalogues named in line_catalogue.

The MASK holds 111 of the 111 rows, over 12 species.

A crossing is attributed where its stellar-frame frequency lies within the adopted half-width of a transition WITH in_mask = 1; code/line_mask.py reproduces every deposited attribution from this table and nu_star_GHz. An attribution is a coincidence in frequency, not an identification of the line: which attributions carry independent support is stated in the article. Each crossing's attribution is in threshold_crossings.csv; this table is the list and the accounting.

**Joins.** transition joins the masked_transition column of threshold_crossings.csv; nu_rest_GHz falls inside the island of frequency_coverage.csv whose edges bracket it.

| column | unit | description |
|---|---|---|
| `transition` | -- | transition label, as used in threshold_crossings.csv |
| `species` | -- | chemical species |
| `quantum_numbers` | -- | quantum numbers as the line catalogue gives them |
| `nu_rest_GHz` | GHz | rest frequency |
| `e_upper_K` | K | upper-state energy; zero for the recombination series, which the catalogues give without one |
| `a_ij_s` | 1/s | Einstein A coefficient where the catalogue gives one |
| `line_catalogue` | -- | the catalogue the entry was taken from |
| `in_mask` | -- | 1 where the attribution mask holds this transition; 0 where the query returned it and the mask leaves it out |
| `mask_exclusion_reason` | -- | why the mask leaves it out, where it does; empty where in_mask is 1 |
| `mask_half_width_kms` | km/s | adopted half-width of the attribution window about the transition; empty where in_mask is 0, which has no attribution window |
| `mask_nu_lo_GHz` | GHz | lower edge of that window |
| `mask_nu_hi_GHz` | GHz | upper edge of that window |
| `mask_width_GHz` | GHz | its width; summed over the searched islands and over the rows with in_mask = 1 this is the bandwidth the mask costs |
| `inside_searched_island` | -- | 1 where the rest frequency lies inside a searched island |
| `n_crossings_attributed` | -- | threshold crossings attributed to this transition |
| `n_crossings_coincident_not_attributed` | -- | crossings lying inside its window that are not attributed to it |

## `candidates/recurrence_tests.csv`

25 rows, 23 columns.

One row per unattributed threshold crossing carrying a repeat-observation measurement: what the covering repeat blocks say about it, read three ways. A line-attributed crossing is tested on the same code path; its reading is the disposition column of threshold_crossings.csv.

sigma_excl_single_cell is the depth at which an emitter at rest in the stellar frame at the discovery flux (a line-like source) is excluded at one predicted cell. It does not test a drifting or re-tuned carrier; every crossing here has a fitted drift, which disfavours that model, so a null at this cell bears little on an accelerating carrier.

The separated columns repeat the reading over covering blocks that satisfy the separation criterion alone -- a different observing session more than a day away -- and the tol columns repeat it over a cell tolerance matched to the measured stellar-frame registration.

p_recovery_measured is the probability the criterion is satisfied by a carrier at the trigger amplitude, measured by injecting that carrier into the retained per-integration spectra of every covering repeat block. tested is 0 where that probability is too low for the reading to be a test, and such a crossing is reported as untested rather than excluded.

An empty field is a value withheld or inapplicable, not a zero: a crossing with no separated covering block has no separated reading.

**Joins.** (eb, nu_topo_GHz) joins threshold_crossings.csv, where star carries the same spelling.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation, as in threshold_crossings.csv |
| `eb` | -- | ALMA execution block identifier of the discovery block |
| `nu_topo_GHz` | GHz | crossing frequency as delivered by the correlator |
| `nu_star_GHz` | GHz | the same frequency in the star rest frame |
| `n_rep` | -- | covering repeat execution blocks the published depth combines |
| `sigma_excl_single_cell` | -- | exclusion depth at the single predicted cell, for a carrier whose stellar-frame frequency is unchanged |
| `n_rep_separated` | -- | of the covering repeats, blocks in a different session more than a day from the discovery block |
| `T_pers_separated` | -- | statistic a persisting carrier would give at the predicted cell over those blocks alone |
| `T_rep_separated` | -- | statistic measured there, at the carried drift |
| `f5_separated` | -- | fraction of the discovery amplitude still excluded at the trigger over those blocks alone; values above 1 exclude nothing |
| `p_trigger_separated` | -- | recovery probability at the trigger amplitude over those blocks alone |
| `k_tol_channels` | channel | half-width of the matched registration tolerance, in channels of the finest covering block |
| `n_cells_tol` | -- | cells read over that tolerance |
| `threshold_tol` | -- | threshold at which those cells carry the single cell's own false-alarm probability |
| `f5_tol` | -- | fraction of the discovery amplitude excluded when the reading is the worst cell of that tolerance; values above 1 exclude nothing |
| `p_trigger_tol` | -- | recovery probability at the trigger amplitude at that threshold |
| `p_recovery_calculated` | -- | probability the criterion is satisfied by a carrier at the trigger amplitude, from the model of the reading |
| `p_recovery_measured` | -- | the same probability measured by injection into the covering repeat blocks |
| `p_recovery_lo` | -- | lower end of its 68 per cent interval |
| `p_recovery_hi` | -- | upper end of that interval |
| `n_realisations` | -- | realisations the measurement is formed from |
| `n_rep_blocks_injected` | -- | covering repeat blocks injected into |
| `tested` | -- | 1 where the measured recovery probability reaches the level required of a test, 0 where the crossing is reported as untested rather than excluded |

## `sensitivity/class_A_limits.csv`

405 rows, 32 columns.

One row per fine-channel spectral window: the sensitivity measurement for the windows that resolve a carrier in one channel.

The limit closes on the columns beside it. eirp_nominal_W times p90_mult_adopted, divided by eta_px_retained, eta_smear_adopted and eta_beam_retained, reproduces eirp_p90_W on every row to better than one part in a million, which is the printed precision of the factors.

The interval is the observed spread between the injected windows, the same pair of factors on every row, and is not a bound measured in a window's own band and channelisation; an injected window's own point, and the class-average interval kept apart from the spread, are in class_A_limit_uncertainty.csv.

The limit is an EIRP at 90 per cent completeness for a carrier inside the searched drift range. It constrains nothing about a transmitter whose apparent acceleration exceeds that range.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins spectral_windows.csv and control_field_statistics.csv -- all four fields, because two positions can share one window of one block; target_id joins stellar_sample.csv.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation, as in stellar_sample.csv |
| `target_id` | -- | identifier the window was extracted under |
| `eb` | -- | ALMA execution block (ASDM) identifier |
| `project_code` | -- | its ALMA project code; cite as ADS/JAO.ALMA# followed by this value |
| `band` | -- | ALMA receiver band |
| `nu_lo_GHz` | GHz | lower edge of the spectral window, topocentric |
| `nu_hi_GHz` | GHz | upper edge of the spectral window, topocentric |
| `chan_width_Hz` | Hz | delivered channel width |
| `dist_pc` | pc | distance adopted for the star |
| `on_source_s` | s | on-source integration time at this position |
| `n_int` | -- | integrations retained at this position |
| `rms_mJy` | mJy | per-channel noise at the extraction position |
| `smin_mJy` | mJy | amplitude limit at the trigger: five times the noise divided by the primary-beam response |
| `pb_atten` | -- | primary-beam response at the star, between 0 and 1 |
| `theta_pb_arcsec` | arcsec | recorded primary-beam FWHM for this window |
| `drift_max_Hz_s` | Hz/s | largest drift rate searched |
| `n_drift_trials` | -- | drift trials searched |
| `eta_drift` | -- | fraction of the drift range over which a carrier is recovered at full amplitude |
| `c_response_smear` | -- | combined spectral-response and intra-channel smearing factor applied to the nominal power |
| `eirp_nominal_W` | W | EIRP of a carrier at the trigger amplitude, before any completeness or retention factor |
| `eirp_eff_total_W` | W | the same power with the spectral response and smearing applied |
| `p90_mult_adopted` | -- | adopted multiplier from the trigger amplitude to 90 per cent completeness: the class factor times the measured response ratio of the window's class and online-averaging mode, from completeness_calibration.csv |
| `eta_px_retained` | -- | fraction of the integrations retained after the phase-centre cut |
| `eta_smear_adopted` | -- | adopted smearing retention for this window |
| `eta_smear_basis` | -- | measured where the retention was measured on this window's own integrations, bounded where it is a bound |
| `eta_beam_retained` | -- | fraction of the applied primary-beam response that the observatory's documented beam retains, clamped at unity |
| `eirp_p90_W` | W | adopted 90 per cent completeness EIRP limit; equals eirp_nominal_W times p90_mult_adopted divided by the three retentions |
| `eirp_p90_lo_W` | W | lower end of its interval: the observed spread between the injected windows, the same pair of factors on every row including the injected ones; each injected window's own point is own_p90_factor in class_A_limit_uncertainty.csv |
| `eirp_p90_hi_W` | W | upper end of that interval, on the same basis |
| `completeness_basis` | -- | injected where this window carries its own injection ladder, transferred otherwise |
| `unmasked_fraction` | -- | fraction of this window channels lying outside the attribution mask, in the star own rest frame; a window at 0 constrains nothing and is in no distribution of limits in the article |
| `trigger_whole_beam` | -- | 1 where the window holds a threshold crossing under the adopted statistic |

## `sensitivity/class_B_limits.csv`

1258 rows, 32 columns.

One row per coarse-channel spectral window: the same sensitivity measurement for the windows whose channel does not resolve a carrier.

The columns, the closure identity and the meaning of the interval are those of class_A_limits.csv.

The completeness multiplier of these windows is a blend and is declared as one in completeness_calibration.csv: no injected coarse window has a bright control ring, so the stratified rule cannot be applied to them.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins spectral_windows.csv -- all four fields, because two positions can share one window of one block; target_id joins stellar_sample.csv.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation, as in stellar_sample.csv |
| `target_id` | -- | identifier the window was extracted under |
| `eb` | -- | ALMA execution block (ASDM) identifier |
| `project_code` | -- | its ALMA project code; cite as ADS/JAO.ALMA# followed by this value |
| `band` | -- | ALMA receiver band |
| `nu_lo_GHz` | GHz | lower edge of the spectral window, topocentric |
| `nu_hi_GHz` | GHz | upper edge of the spectral window, topocentric |
| `chan_width_Hz` | Hz | delivered channel width |
| `dist_pc` | pc | distance adopted for the star |
| `on_source_s` | s | on-source integration time at this position |
| `n_int` | -- | integrations retained at this position |
| `rms_mJy` | mJy | per-channel noise at the extraction position |
| `smin_mJy` | mJy | amplitude limit at the trigger: five times the noise divided by the primary-beam response |
| `pb_atten` | -- | primary-beam response at the star, between 0 and 1 |
| `theta_pb_arcsec` | arcsec | recorded primary-beam FWHM for this window |
| `drift_max_Hz_s` | Hz/s | largest drift rate searched |
| `n_drift_trials` | -- | drift trials searched |
| `eta_drift` | -- | fraction of the drift range over which a carrier is recovered at full amplitude |
| `c_response_smear` | -- | combined spectral-response and intra-channel smearing factor applied to the nominal power |
| `eirp_nominal_W` | W | EIRP of a carrier at the trigger amplitude, before any completeness or retention factor |
| `eirp_eff_total_W` | W | the same power with the spectral response and smearing applied |
| `p90_mult_adopted` | -- | adopted multiplier from the trigger amplitude to 90 per cent completeness: the class factor times the measured response ratio of the window's class and online-averaging mode, from completeness_calibration.csv |
| `eta_px_retained` | -- | fraction of the integrations retained after the phase-centre cut |
| `eta_smear_adopted` | -- | adopted smearing retention for this window |
| `eta_smear_basis` | -- | measured where the retention was measured on this window's own integrations, bounded where it is a bound |
| `eta_beam_retained` | -- | fraction of the applied primary-beam response that the observatory's documented beam retains, clamped at unity |
| `eirp_p90_W` | W | adopted 90 per cent completeness EIRP limit; equals eirp_nominal_W times p90_mult_adopted divided by the three retentions |
| `eirp_p90_lo_W` | W | lower end of its interval: the observed spread between the injected windows, the same pair of factors on every row including the injected ones; each injected window's own point is own_p90_factor in class_A_limit_uncertainty.csv |
| `eirp_p90_hi_W` | W | upper end of that interval, on the same basis |
| `completeness_basis` | -- | injected where this window carries its own injection ladder, transferred otherwise |
| `unmasked_fraction` | -- | fraction of this window channels lying outside the attribution mask, in the star own rest frame; a window at 0 constrains nothing and is in no distribution of limits in the article |
| `trigger_whole_beam` | -- | 1 where the window holds a threshold crossing under the adopted statistic |

## `sensitivity/class_A_limit_uncertainty.csv`

405 rows, 22 columns.

One row per fine-channel spectral window: what its limit is uncertain by, kept apart by kind.

The class-average calibration interval is one number shared by every window and moves every limit together; the dispersion between injected windows is the statement about one window, and for an extrapolated window it is not an empirical bound. Decorrelation and the delivered response are one-sided and are given as corrected limits, not intervals.

eirp_p90_W is the limit of class_A_limits.csv on every row.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins class_A_limits.csv and spectral_windows.csv -- all four fields, because two positions can share one window of one block.

| column | unit | description |
|---|---|---|
| `target_id` | -- | identifier the window was extracted under |
| `system_id` | -- | the stellar system the window counts toward |
| `eb` | -- | ALMA execution block (ASDM) identifier |
| `nu_lo_GHz` | GHz | lower edge of the spectral window, topocentric |
| `nu_hi_GHz` | GHz | upper edge of the spectral window, topocentric |
| `chan_width_Hz` | Hz | delivered channel width |
| `n_chan_avg` | -- | online spectral averaging factor N; the archive's resolution-to-spacing ratio gives the same N for every window |
| `calibration_label` | -- | measured where carriers were injected into this window; interpolated where it lies inside the injected range on band, channel width, array configuration, integration time and block duration; extrapolated where it lies outside on at least one |
| `outside_injected_on` | -- | for an extrapolated window, the properties on which it leaves the injected range |
| `own_p90_factor` | -- | for a measured window, its own ninety per cent point in units of its trigger power; empty otherwise |
| `class_p90_factor` | -- | the class-average factor every Class A limit carries |
| `eirp_p90_W` | W | the adopted limit, as in class_A_limits.csv |
| `eirp_p90_dispersion_lo_W` | W | a measured window: its limit at its own factor; a transferred window: its limit at the smallest factor any injected window gave. An empirical bound only for an interpolated window |
| `eirp_p90_dispersion_hi_W` | W | the same at the largest factor, on the same basis |
| `eirp_p90_classavg_lo_W` | W | the limit at the low end of the class-average calibration interval; that interval moves every limit together and applies to statistics over many windows |
| `eirp_p90_classavg_hi_W` | W | the limit at the high end of that interval |
| `decorrelation_frac` | -- | fraction by which atmospheric decorrelation leaves this limit optimistic; empty where the block has neither a phase record nor a baseline to match on |
| `decorrelation_basis` | -- | measured from the block's own phase record, matched from blocks of similar baseline, or none |
| `eirp_p90_decor_adjusted_W` | W | the limit with that decorrelation divided out; empty where none is available |
| `response_ratio` | -- | the injected tone's phase-mean peak-channel share over that of the exact delivered response for this window's N; the injections deposited the N = 1 profile in every window |
| `eirp_p90_response_corrected_W` | W | the limit with the exact delivered response in place of the injected one |
| `limit_eligible` | -- | 1 where the attribution mask leaves channels for a limit, 0 where it leaves none |

## `sensitivity/system_limits.csv`

60 rows, 24 columns.

One row per system of the carrier search that carries a limit: its headline limit, the limit at both ends of the class-average interval, with decorrelation and with the exact delivered response divided out, and the probability that it reaches 1e15 W when each transferred window's factor is drawn from the injected windows' own points.

A system marked uncertain is one whose classification at 1e15 W the calibration interval, the dispersion, the decorrelation or the response can change.

**Joins.** system joins class_A_limit_uncertainty.csv on system_id; (best_eb, best_nu_lo_GHz) names the window the headline limit is read from.

| column | unit | description |
|---|---|---|
| `designation` | -- | the system, as the article names it |
| `system` | -- | the system identifier of class_A_limit_uncertainty.csv |
| `best_eb` | -- | execution block of the system's best window |
| `best_nu_lo_GHz` | GHz | lower edge of that window |
| `eirp90_W` | W | the system's headline limit, the minimum over its eligible Class A windows |
| `basis` | -- | calibration label of the best window |
| `own_factor` | -- | the best window's own ninety per cent point where it was injected into |
| `n_chan_avg` | -- | the best window's online spectral averaging factor |
| `eirp90_cal_lo_W` | W | the headline limit at the low end of the class-average interval |
| `eirp90_cal_hi_W` | W | the headline limit at the high end of the class-average interval |
| `p_reach_window` | -- | fraction of resamplings in which the system reaches 1e15 W, each transferred window drawing its factor independently from the injected windows' own points; measured windows keep their own |
| `p_reach_block` | -- | the same with one draw per execution block, the windows of a block sharing it |
| `p_reach_window_dec` | -- | the window-by-window resampling with decorrelation divided out |
| `sys_ratio_p05_block` | -- | fifth percentile of the headline limit over the block resampling, as a fraction of the adopted limit |
| `sys_ratio_p95_block` | -- | ninety-fifth percentile, on the same basis |
| `decor_frac` | -- | decorrelation fraction of the best window |
| `decor_basis` | -- | measured, matched or none |
| `eirp90_decor_adjusted_W` | W | headline limit with decorrelation divided out window by window and the best window chosen again |
| `eirp90_response_corrected_W` | W | headline limit with the exact delivered response in every window and the best window chosen again |
| `reaches_1e15_nominal` | -- | True where the adopted headline limit is at or below 1e15 W |
| `uncertain` | -- | why the 1e15 W classification is uncertain: dispersion (a resampled probability between 0.05 and 0.95), calibration interval, decorrelation, exact response, or extrapolated (the threshold lies within the measured dispersion of an extrapolated limit); empty where it is not |
| `eirp90_spread_lo_W` | W | the system limit with every transferred window at the deepest injected factor (x the dispersion minimum), injected windows at the class factor, best window re-formed |
| `eirp90_spread_hi_W` | W | the same at the shallowest injected factor (x the dispersion maximum) |
| `crosses_1e15_at_spread_extreme` | -- | True where either extreme puts the system on the other side of 1e15 W from its nominal limit |

## `sensitivity/injection_recovery.csv`

4032 rows, 24 columns.

One row per injection trial: a carrier of known amplitude, channel and drift rate put into the retained per-integration spectra of a real window and read back by the unchanged search path.

These trials are PART of the campaign the completeness transfer is calibrated on, not all of it: they cover 28 of the 49 directly injected Class A windows. The trials span the configurations of the survey -- both arrays, four receiver bands, channel widths from the finest to the coarsest -- and at each amplitude the recovered fraction over the realisations is the completeness at that amplitude.

★ THE 90 PER CENT POINT OF THESE TRIALS IS NOT THE PUBLISHED MULTIPLIER, and reading one against the other is the one mistake this table invites. The article publishes 2.99 P_trig, which factorises as x2.286 for the channel response and x1.309 for the margin a peak channel needs above the nominal trigger. The channel response is ALREADY INSIDE these trials -- each carrier is deposited at a random sub-channel phase through the correlator response, whose central channel receives 0.4375 of it on average -- so a curve formed from these rows measures the MARGIN TERM ALONE and lands near x1.2 of the trigger. code/injection_recovery.py prints the arithmetic beside the number.

What is measured is the reading: the de-drifting, the drift trials, the control normalisation and the threshold. It is not the step from calibrated visibilities to a spectrum, which is upstream of the injection point and is not tested here.

detected is the search's own verdict, which requires the recovered statistic to reach the trigger; drift_matched records separately whether the recovered drift trial was the injected one, and a trial can be detected without it.

**Joins.** (target_id, eb, window_nu_lo_GHz, window_nu_hi_GHz) joins the sensitivity tables and spectral_windows.csv. One injected window is shared by two extraction positions; its rows carry the window and leave target_id and star empty rather than assign the trial to one of them, and it is the one window of this table whose three remaining fields match two rows of spectral_windows.csv, so those rows join on the window and not on the position.

| column | unit | description |
|---|---|---|
| `eb` | -- | ALMA execution block the injected window belongs to |
| `target_id` | -- | identifier of the extraction position, empty where one window serves two |
| `star` | -- | its star designation, empty on the same rows |
| `window_nu_lo_GHz` | GHz | lower edge of the injected window |
| `window_nu_hi_GHz` | GHz | upper edge of the injected window |
| `band` | -- | ALMA receiver band |
| `array` | -- | 12m for the main array, ACA for the compact array |
| `chan_width_Hz` | Hz | delivered channel width of the window |
| `n_int` | -- | integrations the injection was made into |
| `n_chan` | -- | channels in the window |
| `span_s` | s | time span of those integrations |
| `n_drift_trials` | -- | drift trials the reading searched |
| `theta_pb_arcsec` | arcsec | recorded primary-beam FWHM of the window |
| `amp_sigma` | -- | injected amplitude in units of the per-channel noise |
| `realisation` | -- | realisation index at that amplitude; channel and drift are redrawn for each |
| `inj_flux_Jy` | Jy | injected flux density |
| `inj_channel` | -- | channel the carrier was injected at |
| `inj_drift_Hz_s` | Hz/s | drift rate it was injected with |
| `rec_statistic` | -- | de-drifted search statistic recovered at the injected cell |
| `rec_channel` | -- | channel it was recovered at |
| `rec_drift_Hz_s` | Hz/s | drift rate it was recovered at |
| `window_max_statistic` | -- | largest statistic anywhere in the window on that trial |
| `drift_matched` | -- | 1 where the recovered drift trial is the injected one |
| `detected` | -- | 1 where the trial satisfies the search's own detection condition |

## `sensitivity/injection_trials.csv`

10332 rows, 14 columns.

One row per injection trial behind the Class A completeness factor: every trial of the 49 directly injected windows, 10332 in all, a carrier deposited through the channel response at a random sub-channel phase and drift into the retained per-integration spectra of a real window and read back by the unchanged search path.

The amplitude is in units of the window's own trigger power P_trig. The class factor is the amplitude at which the pooled fraction reaching the trigger first reaches the completeness level of completeness_parameters.csv, linearly interpolated between rungs, the positive-control rung excluded; each window's own point is the same construction on its own trials. code/completeness.py rebuilds the factor, its bootstrap and calibration intervals and the per-window points from this file and completeness_parameters.csv alone.

window_tag is the correlator stem of the window (block and spectral window). One injected window is shared by two extraction positions; its rows leave target_id empty.

**Joins.** (target_id, eb, window_nu_lo_GHz, window_nu_hi_GHz) joins spectral_windows.csv and the sensitivity tables; window_tag groups the trials of one window.

| column | unit | description |
|---|---|---|
| `window_tag` | -- | correlator stem of the injected window |
| `eb` | -- | ALMA execution block identifier |
| `target_id` | -- | identifier of the extraction position, empty where one window serves two |
| `window_nu_lo_GHz` | GHz | lower edge of the window |
| `window_nu_hi_GHz` | GHz | upper edge of the window |
| `chan_width_Hz` | Hz | delivered channel width |
| `span_s` | s | time span of the integrations searched |
| `amp_over_trigger` | -- | injected power in units of the window trigger power P_trig, full precision |
| `subchannel_phase` | -- | offset of the injected frequency from the channel centre, in channels |
| `inj_drift_Hz_s` | Hz/s | drift rate the carrier was injected with |
| `rec_statistic` | -- | largest de-drifted statistic at the star within the recovery tolerance of the injected frequency |
| `reached_trigger` | -- | 1 where that statistic reaches the trigger: the criterion of the class factor |
| `outranked_controls` | -- | 1 where it also exceeds every control position of the window |
| `recovered_with_rank` | -- | 1 where both hold: the stricter criterion the article does not charge |

## `sensitivity/completeness_parameters.csv`

9 rows, 2 columns.

The scalar inputs of the completeness factor and its intervals, one row per parameter. The parameters are:

completeness_level -- recovered fraction defining the completeness point.

positive_control_amp -- amplitude of the positive-control rung, excluded from every curve.

bootstrap_seed -- seed of Python random.Random drawing window indices for the bootstrap.

bootstrap_n -- bootstrap resamplings of the windows.

bootstrap_q_lo -- quantile of the sorted bootstrap points giving the lower end.

bootstrap_q_hi -- and the upper end.

spread_pct_lo -- percentile of the per-window points giving the lower end of their spread.

spread_pct_hi -- and the upper end.

instrumental_fraction -- fractional instrumental term (flux scale, parallax, visibility scale) combined in quadrature with the bootstrap error in the calibration interval.

**Joins.** read with injection_trials.csv

| column | unit | description |
|---|---|---|
| `parameter` | -- | parameter name, described above |
| `value` | -- | its value |

## `sensitivity/response_injection_trials.csv`

19762 rows, 13 columns.

One row per injection trial of the channel-response campaign: 35 windows of every search class and online-averaging mode, each injected with the deposited 0.25/0.5/0.25 profile and, on identical carriers, with the window's own channel response (Hann-windowed raw channels averaged online by N), 19762 trials in all.

For each class and mode the ratio of the pooled ninety-per-cent points (own response over deposited profile, paired carriers) multiplies the class factor of every window of that class and mode. code/response_ratio.py rebuilds every ratio and factor from this file, response_parameters.csv and injection_trials.csv.

model is deposited_profile, own_response_paired (the same carriers) or own_response_independent (other seeds, a check only).

**Joins.** window_tag and model group the trials of one window and model; search_class and n_chan_avg select the mode.

| column | unit | description |
|---|---|---|
| `window_tag` | -- | correlator stem of the injected window |
| `model` | -- | channel response the carrier was deposited with |
| `search_class` | -- | A or B |
| `n_chan_avg` | -- | online channel averaging N of the window |
| `field_injected` | -- | 1 where every pointing of a mosaic was injected at the star |
| `chan_width_Hz` | Hz | delivered channel width |
| `amp_over_trigger` | -- | injected power in units of the window trigger power P_trig, full precision |
| `subchannel_phase` | -- | offset of the injected frequency from the channel centre, in channels |
| `inj_drift_Hz_s` | Hz/s | drift rate the carrier was injected with |
| `rec_statistic` | -- | largest de-drifted statistic at the star within the recovery tolerance |
| `reached_trigger` | -- | 1 where that statistic reaches the trigger: the criterion of the factor |
| `outranked_controls` | -- | 1 where it also exceeds every control position (empty: not recorded) |
| `recovered_with_rank` | -- | 1 where both hold (empty: not recorded) |

## `sensitivity/response_parameters.csv`

4 rows, 2 columns.

The scalar inputs of the channel-response ratios, one row per parameter. The parameters are:

completeness_level -- recovered fraction defining the completeness point.

positive_control_amp -- amplitude of the positive-control rung, excluded from every curve.

amplitude_ladder -- the rungs, in units of P_trig.

class_level_B -- the Class B class factor (x P_trig) the ratios of Class B multiply; the Class A level is rebuilt from injection_trials.csv.

**Joins.** read with response_injection_trials.csv

| column | unit | description |
|---|---|---|
| `parameter` | -- | parameter name, described above |
| `value` | -- | its value |

## `sensitivity/completeness_calibration.csv`

15 rows, 11 columns.

How the completeness of the survey was measured, and how it was carried to the windows that were not tested directly.

Only a minority of windows carry their own injection ladder; every other window takes a multiplier calibrated on those that do, and the table records which windows were tested, the rule that defines each stratum, the measured multiplier and its interval.

The interval on a transferred limit is one pair of factors over every transferred row, because it is the dispersion observed between the injected windows. It is not a bound measured in any one window's own band and channelisation, and it does not describe a window that lies in a configuration no injection visited.

One stratum carries a bound rather than a measurement, and says so: in windows with a bright control position the carrier is recovered in every trial at the positive control, so the multiplier is bounded from above and not determined.

**Joins.** completeness_basis and search_class in the sensitivity tables select the windows each row applies to; the trials themselves are in injection_recovery.csv.

| column | unit | description |
|---|---|---|
| `stratum` | -- | the set of windows this row calibrates |
| `selection_rule` | -- | the rule that defines that set, in terms of the deposited columns |
| `quantity` | -- | what is being given |
| `value` | -- | its value |
| `lo` | -- | lower end of its interval where it has one |
| `hi` | -- | upper end of its interval where it has one |
| `n_catalogue_windows` | -- | windows in the stratum |
| `n_injected_windows` | -- | of those, windows carrying their own injection ladder |
| `n_injected_windows_deposited` | -- | of those, windows whose individual trials are deposited in injection_recovery.csv; the rest were injected but their per-trial rows are not released, so a curve formed from the deposited rows is formed over this subset |
| `applies_to` | -- | the windows the value is applied to |
| `note` | -- | the qualification that travels with the value; where a value is a bound or a blend rather than a measurement, this column says so |

## `statistics/control_field_statistics.csv`

405 rows, 29 columns.

One row per window with a control ensemble: the control-field measurement the chance comparison is built from.

The control positions lie in an annulus set by the primary beam of the dish that observed the window and by its synthesised beam: r_in = max(0.14 theta_pb, ann_syn_factor x syn_arcsec), r_out = 0.78 theta_pb. ring_r_in_arcsec and ring_r_out_arcsec are that annulus for the window, and code/control_positions.py --check reproduces them row by row.

Rows with geometry_provenance = frozen-geometry predate the repair that reads the dish from the data: their annulus assumed a 12 m dish and has no synthesised-beam floor. On the 12 m array that is the same rule; the check lists by name any such row observed with 7 m antennas.

p_trig_ctrl is the window's own probability that a position in its field reaches the trigger, measured as the fraction of its control positions that do. The sum of that probability over the fine-channel windows, each reduced by the share the attribution mask takes and by the atmospheric factor, is the chance expectation of null_distribution_tests.csv.

p_rank is the rank of the stellar statistic among the control positions of the same window, formed with the add-one correction. It is a diagnostic and not a significance test.

The control channels are transformed to the same stellar rest frame as the star's own reading before the attribution mask is applied to them, so the two sides of the comparison are screened in one frame.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins spectral_windows.csv and the sensitivity tables.

| column | unit | description |
|---|---|---|
| `star` | -- | star designation |
| `target_id` | -- | identifier the window was extracted under |
| `eb` | -- | ALMA execution block identifier |
| `project_code` | -- | its ALMA project code |
| `nu_lo_GHz` | GHz | lower edge of the window |
| `nu_hi_GHz` | GHz | upper edge of the window |
| `search_class` | -- | A fine or B coarse |
| `rms_mJy` | mJy | per-channel noise at the stellar position |
| `theta_pb_arcsec` | arcsec | primary-beam FWHM, 1.22 lambda / D, the annulus was built from |
| `ring_r_in_arcsec` | arcsec | inner radius of the control annulus |
| `ring_r_out_arcsec` | arcsec | outer radius of the control annulus |
| `array` | -- | 12m or 7m: the array that observed the window, from the archive |
| `geometry_provenance` | -- | corrected-geometry or frozen-geometry: whether the extraction that produced this row read the dish from the data |
| `annulus_dish_m` | m | dish diameter the annulus was built for |
| `syn_arcsec` | arcsec | synthesised-beam FWHM used for the inner-edge floor; empty where no floor was applied |
| `ann_syn_factor` | -- | the floor in synthesised beams; empty where no floor was applied |
| `ring_centre` | -- | what the annulus is centred on |
| `ring_seed` | -- | seed the control positions were drawn with, so the ensemble is reproducible |
| `n_ctrl` | -- | control positions in the ensemble |
| `T_star` | -- | de-drifted search statistic at the stellar position |
| `T_ctrl_max` | -- | largest statistic among the control positions |
| `n_ctrl_ge_star` | -- | control positions whose statistic reaches the stellar one |
| `p_rank` | -- | rank of the stellar statistic among them, with the add-one correction; a diagnostic and not a significance test |
| `n_ctrl_trig` | -- | control positions reaching the trigger |
| `p_trig_ctrl` | -- | the window's own probability that a position in its field reaches the trigger |
| `mask_attr_share` | -- | share of its control exceedances the attribution mask takes, in the star rest frame |
| `telluric_factor` | -- | factor by which the remaining exceedances are reduced by the atmospheric screen |
| `n_search_cells` | -- | search cells in the window |
| `n_ind_cells` | -- | independent cells after the correlation between neighbouring drift trials is accounted for |

## `statistics/chance_resampling_windows.csv`

810 rows, 13 columns.

One row per Class A window with a control ensemble and per field reading: the inputs of the block resampling behind the probability, the added-population bound and the interval of the chance comparison, in the order the resampling consumes them (block_order, then window_order).

code/chance_expectation.py reads this file with chance_resampling_blocks.csv and chance_resampling_parameters.csv and nothing else.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins control_field_statistics.csv and spectral_windows.csv; field_reading selects one of the two readings

| column | unit | description |
|---|---|---|
| `field_reading` | -- | whole_beam (the adopted reading) or narrow_field |
| `block_order` | -- | position of the execution block in the resampled list |
| `window_order` | -- | position of the window inside its block |
| `eb` | -- | ALMA execution block identifier |
| `target_id` | -- | identifier the window was extracted under |
| `nu_lo_GHz` | GHz | lower edge of the window |
| `nu_hi_GHz` | GHz | upper edge of the window |
| `n_ctrl` | -- | control positions of the window |
| `n_ctrl_trig` | -- | of them, reaching the trigger; the window rate is n_ctrl_trig / n_ctrl |
| `attribution` | -- | measured: the attributed share is the pooled share of recorded control exceedances landing in the mask; grid: the share of the window channel grid the mask covers |
| `grid_mask_share` | -- | share of the window channel grid inside the mask, star rest frame, full precision |
| `n_exc_recorded` | -- | control exceedances of this window whose landing channel is recorded; empty where none is |
| `n_exc_in_mask` | -- | of them, inside the mask; empty on the same rows |

## `statistics/chance_resampling_blocks.csv`

256 rows, 5 columns.

The recorded control exceedances summed per execution block, in the order the attributed share is resampled: one realisation of the share is the in-mask total over the total, over one resampling of these rows.

**Joins.** eb joins execution_blocks.csv; field_reading as in chance_resampling_windows.csv

| column | unit | description |
|---|---|---|
| `field_reading` | -- | whole_beam or narrow_field |
| `attr_order` | -- | position of the block in the resampled list |
| `eb` | -- | ALMA execution block identifier |
| `n_exc_in_mask` | -- | recorded control exceedances of the block inside the mask |
| `n_exc_recorded` | -- | recorded control exceedances of the block |

## `statistics/chance_resampling_parameters.csv`

50 rows, 3 columns.

The scalar inputs of the chance resampling, one row per parameter and field reading. The parameters are:

seed -- seed of the NumPy default generator (PCG64) the resampling draws from.

numpy_version -- NumPy release the reported draws were made with; another release may draw a different stream and then agrees only within the Monte Carlo error.

n_realisations -- realisations of every window rate and of the two shared shares.

n_batches -- disjoint batches of realisations; resampling b reads batch b mod n_batches.

n_boot -- block resamplings.

n_observed -- unattributed Class A crossings compared with the expectation.

n_reference_windows -- windows the per-window mean rate is scaled to.

scale -- ratio of the reference window count to the windows tabulated.

alpha -- level at which the added-population bound is set.

coverage_pct -- coverage of the quoted intervals, per cent.

trigger -- the trigger level T_star.

n_exc_recorded -- control exceedances whose landing channel is recorded.

n_exc_in_mask -- of them, landing inside the attribution mask in the star rest frame.

n_exc_survive_mask -- recorded exceedances the mask leaves.

n_exc_telluric_only -- of those, removed by the atmospheric screen.

n_holdout_blocks -- reserved blocks whose resampling the generator stream passes through between the expectation and its transferred interval.

transfer_band_lo -- lower end of the star-to-control transfer band applied to the interval.

transfer_band_hi -- upper end of that band.

near_band_lo -- lower edge of the sub-trigger band the star-to-control ratio is measured in.

near_band_hi -- its upper edge.

near_n_star_events -- out-of-mask stellar cells in that band.

near_n_control_events -- out-of-mask control cells in that band.

near_n_windows -- windows the band is counted over.

near_n_control_positions -- control positions it is counted over.

max_ext_chunks -- cap on independent replicates added when an integer bound is not stable within two Monte Carlo errors.

**Joins.** field_reading as in chance_resampling_windows.csv

| column | unit | description |
|---|---|---|
| `field_reading` | -- | whole_beam or narrow_field |
| `parameter` | -- | parameter name, described above |
| `value` | -- | its value |

## `statistics/recurrence_windows.csv`

93 rows, 11 columns.

One row per distinct covering window of the widened recurrence comparison: a window of a block of another session, more than a day from the discovery block, covering the frequency of an unattributed crossing; a window covering several crossings is one row.

code/recurrence_expectation.py reads it with recurrence_parameters.csv, look_elsewhere_groups.csv and control_field_statistics.csv.

**Joins.** (eb, nu_lo_GHz, nu_hi_GHz) joins control_field_statistics.csv and spectral_windows.csv

| column | unit | description |
|---|---|---|
| `window_order` | -- | position of the window in the order the comparison is formed |
| `eb` | -- | ALMA execution block identifier |
| `nu_lo_GHz` | GHz | lower edge of the window, full precision |
| `nu_hi_GHz` | GHz | upper edge of the window, full precision |
| `star` | -- | catalogue name the window was searched under |
| `object` | -- | the object it belongs to, as the article names it |
| `search_class` | -- | A fine or B coarse channels |
| `statistic` | -- | the window statistic read, the largest over the window |
| `above_trigger` | -- | 1 where it reaches the trigger |
| `p_trig_ctrl` | -- | fraction of the window control positions reaching the trigger, the rate the whole comparison and its two-object split are formed on; empty where the window has no control vector |
| `p_trig_cells` | -- | the window chance of a trigger crossing from its independent channel-drift cells, a secondary null; empty where the cell count is not recorded |

## `statistics/look_elsewhere_groups.csv`

228 rows, 6 columns.

The groups of every look-elsewhere simulation, in the order the simulations consume the random stream: one row per member probability of one group (an object). Each simulation draws every group's count from its own Poisson-binomial distribution and records the smallest group tail of each realisation.

**Joins.** object as in recurrence_windows.csv

| column | unit | description |
|---|---|---|
| `call` | -- | order of the simulation in the stream |
| `purpose` | -- | edge landing, control rates (the one the article quotes) or cell rates |
| `group` | -- | order of the group inside the simulation |
| `object` | -- | the object the group is |
| `member` | -- | order of the probability inside the group |
| `p` | -- | the member probability, full precision |

## `statistics/recurrence_parameters.csv`

11 rows, 2 columns.

The scalar inputs of the widened recurrence comparison. The parameters are:

seed -- seed of numpy.random.default_rng for the look-elsewhere simulations.

n_sim -- realisations per simulation.

numpy_version -- NumPy release the article was computed with.

trigger -- the trigger statistic.

first_star -- catalogue name (star column) of one of the two objects the article names.

second_star -- catalogue name of the other.

first_object -- object name of HD 14055 in recurrence_windows.csv.

second_object -- object name of the other object in recurrence_windows.csv.

p_obs_call_1 -- the tail the simulation of call 1 (edge landing) compares each realisation with.

p_obs_call_2 -- the tail the simulation of call 2 (control rates) compares each realisation with.

p_obs_call_3 -- the tail the simulation of call 3 (cell rates) compares each realisation with.

**Joins.** none

| column | unit | description |
|---|---|---|
| `parameter` | -- | parameter name, described above |
| `value` | -- | its value |

## `sensitivity/sensitivity_resampling_windows.csv`

390 rows, 10 columns.

One row per Class A window that constrains bandwidth, in the order the sensitivity resampling consumes them: the window's EIRP_90 limit is factor_free_limit_W times its completeness factor, and a system's limit is the smallest over its windows.

code/sensitivity_summary.py reads this file with sensitivity_resampling_pool.csv and sensitivity_resampling_parameters.csv and nothing else.

**Joins.** (target_id, eb, nu_lo_GHz, nu_hi_GHz) joins spectral_windows.csv and class_A_limit_uncertainty.csv; system_id joins system_limits.csv

| column | unit | description |
|---|---|---|
| `window_order` | -- | position of the window in the resampled list |
| `eb` | -- | ALMA execution block identifier |
| `target_id` | -- | identifier the window was extracted under |
| `nu_lo_GHz` | GHz | lower edge of the window |
| `nu_hi_GHz` | GHz | upper edge of the window |
| `system_id` | -- | the system the window belongs to |
| `factor_free_limit_W` | W | the limit divided by the completeness factor, full precision |
| `injected` | -- | 1 where the window was itself injected into and keeps its own measured factor |
| `own_factor` | -- | that measured factor; empty for a transferred window |
| `decorrelation_factor` | -- | one plus the fraction by which atmospheric decorrelation leaves the limit optimistic |

## `sensitivity/sensitivity_resampling_pool.csv`

49 rows, 2 columns.

The measured completeness factors of the injected windows, the pool a transferred window's factor is drawn from; the centred pool is this one scaled to the class factor's mean.

**Joins.** pool_order is the order the values are indexed by the draws

| column | unit | description |
|---|---|---|
| `pool_order` | -- | index of the value |
| `own_factor` | -- | one injected window's own ninety-per-cent point, in units of its trigger power |

## `sensitivity/sensitivity_resampling_parameters.csv`

7 rows, 2 columns.

The scalar inputs of the sensitivity summaries, one row per parameter, with the NumPy release the reported draws were made with. The parameters are:

class_factor -- the Class A completeness factor every window carries.

factor_lo -- lower end of its calibration interval, as a multiple of it.

factor_hi -- upper end.

level_W -- the EIRP level systems are counted at.

seed -- seed of the NumPy default generator (PCG64).

n_trial -- trials per resampling.

numpy_version -- NumPy release of the reported draws.

**Joins.** read with sensitivity_resampling_windows.csv

| column | unit | description |
|---|---|---|
| `parameter` | -- | parameter name, described above |
| `value` | -- | its value |

## `statistics/above_threshold_cells.csv`

7 rows, 6 columns.

The number of search cells above each level, counted at the stellar positions and at the control positions, from well below the trigger up to it.

The ratio of the two, normalised by the number of positions on each side, is the step from a control position rate to a stellar position rate. The article adopts the control rate -- the smaller of the two and the more demanding of the count under test -- and carries this step only as a sensitivity test; these are the counts that step is formed from.

The ratio is empty at the highest level, where neither side holds a cell. A ratio formed from a handful of cells at the top of the ladder carries the uncertainty of those counts and nothing here hides it: the counts are given so that uncertainty can be formed.

These counts are measured over the fine-channel windows of the released extent at the time the ladder was built, which is the number in n_windows.

The adopted band is one pair of these rungs differenced. The step quoted in null_distribution_tests.csv is formed over 4 <= T < 5, and its two cell counts are this table's 4 rows less its 5 rows on each side; its ratio is the same arithmetic. The ratio rises monotonically toward the trigger, which is why the band adopted is the one adjacent to it and not a wider one further below: a wider band measures the quantity where it is smaller.

**Joins.** the levels are in units of the per-channel noise, the same units as the T_star columns; the step this table supports is in null_distribution_tests.csv.

| column | unit | description |
|---|---|---|
| `threshold_sigma` | -- | level, in units of the per-channel noise |
| `n_star_cells` | -- | search cells above that level at the stellar positions |
| `n_control_cells` | -- | search cells above it at the control positions, pooled over the ensemble |
| `ratio` | -- | stellar rate divided by control rate at that level, normalised by the number of positions on each side; empty where neither side holds a cell |
| `n_windows` | -- | fine-channel windows the counts are formed over |
| `basis` | -- | what is counted |

## `statistics/null_distribution_tests.csv`

39 rows, 6 columns.

The chance comparison and the tests around it, term by term: what was expected, what was observed, and on what assumptions.

The comparison is made twice, over two fields, and both readings are here. The adopted reading is the whole primary beam, which is the field the statistic is defined over; the other reads both sides over the narrower extraction field, which drops the integrations whose pointing falls outside it. Neither is a reading of the other.

value is the figure the article prints, at the precision it prints it. exact is the figure the record carries before rounding, where there is one. A quantity the article does not print has an empty value and an exact figure.

The expectation can be rebuilt from control_field_statistics.csv: sum each fine-channel window p_trig_ctrl, multiply each by one minus its mask_attr_share and by its telluric_factor. The interval on it cannot, because it folds in the transfer band of above_threshold_cells.csv and the resampling of the attributed share.

What the comparison establishes is consistency with the expectation these fields' own control positions set, under the assumptions recorded here. It does not establish that the unattributed crossings are noise.

**Joins.** the per-window terms are in control_field_statistics.csv; the cell counts behind the sub-trigger step are in above_threshold_cells.csv, and its band_lo and band_hi rows name the two rungs of that table they are differenced from, so the two files quote one band and not two; the crossings counted on the observed side are the rows of threshold_crossings.csv with attributed = 0.

| column | unit | description |
|---|---|---|
| `test` | -- | the test or quantity group the row belongs to |
| `reading` | -- | the field the quantity is read over, or the block set it is measured on |
| `quantity` | -- | what is given |
| `value` | -- | the figure the article prints, at the precision it prints it; empty where the article does not print it |
| `exact` | -- | the figure the analysis record carries before rounding, where there is one |
| `note` | -- | what the quantity is and the assumption it rests on |

## `catalogues/count_accounting.csv`

36 rows, 5 columns.

The master accounting of the survey: one row per published count, with the sub-counts each one partitions into.

Every count in the article appears here, and so do the itemised rows the article does not have room for; in_article records which is which.

The row numbers nest: every sub-row is a subset of its parent, and a row whose note names sub-rows is their sum. Where a count appears under two parents the note says so, because a count that is reached by two routes and does not agree is a defect and not a nuance.

**Joins.** the crossing counts are the rows of threshold_crossings.csv under the selections the notes give; the window counts are those of spectral_windows.csv.

| column | unit | description |
|---|---|---|
| `row` | -- | row number; a sub-row is a subset of its parent row |
| `count` | -- | what is counted |
| `value` | -- | the published value |
| `what_it_counts` | -- | the qualification that travels with the count |
| `in_article` | -- | 1 where the article prints this row, 0 where it is itemisation the article has no room for |

## `candidates/drift_pair_accounting.csv`

11 rows, 4 columns.

The accounting of the trajectory test over pairs of crossings toward one star: how many covering windows were read, how many distinct pairs those readings represent, and how the pairs divide under the bounded-trajectory criterion.

Each block of rows is a partition of the first row of its block; a row marked as a subset counts part of the row above it.

**Joins.** the crossings are the rows of threshold_crossings.csv; the covering windows are rows of spectral_windows.csv.

| column | unit | description |
|---|---|---|
| `block` | -- | the group of rows this row belongs to; the rows of a group are counted over one population |
| `subset_of_previous` | -- | 1 where the row counts part of the row before it, 0 where it opens a count |
| `quantity` | -- | what is counted |
| `count` | -- | the count |

## `candidates/repeat_epoch_readings.csv`

26 rows, 3 columns.

For the two crossings whose statistic exceeds every control position of their window, the readings of the repeat epochs behind each bound: the largest single epoch, the maximum over every drift and the value over the matched registration tolerance, with the frequencies in each frame.

One row per quantity and star.

**Joins.** star joins threshold_crossings.csv on the crossing toward that star whose statistic exceeds every control position.

| column | unit | description |
|---|---|---|
| `quantity` | -- | the reading or frequency, with the frame or epoch it is taken in |
| `star` | -- | the star of the crossing |
| `value` | -- | the value, in the unit the quantity names (GHz for frequencies; the search statistic otherwise) |

## `statistics/recalibration_blocks.csv`

285 rows, 8 columns.

One row per execution block recalibrated with ALMA's final flags, or behind a quoted limit or a threshold crossing and not recalibrated, with the reason. Blocks that are not recalibrated keep the delivered calibration.

**Joins.** eb joins spectral_windows.csv.

| column | unit | description |
|---|---|---|
| `eb` | -- | execution-block identifier |
| `stars` | -- | the stars the block observes, separated by semicolons |
| `role` | -- | why the block is listed: it sets a quoted limit or holds a crossing, or holds a repeat epoch or a runner-up window |
| `carries_limit` | -- | 1 if the block sets a quoted limit |
| `carries_crossing` | -- | 1 if the block holds a threshold crossing |
| `fate` | -- | recalibrated, or the reason it was not |
| `how` | -- | how the flags were restored, or the measurement behind the reason |
| `asdm_GB` | GB | size of the delivered data |

## `statistics/extractor_version_sample.csv`

61 rows, 9 columns.

Windows rerun with the archived extractor and compared with the statistic they carried before. sample = random: census blocks drawn at random among those not recalibrated (one per star, small deliveries), rerun without ALMA's flags so that only the extractor differs; these are the windows the article quotes. sample = flags_unchanged: recalibrated blocks whose flags did not change; a selected set, not a random one.

**Joins.** eb and the window edges join spectral_windows.csv.

| column | unit | description |
|---|---|---|
| `sample` | -- | random or flags_unchanged |
| `eb` | -- | execution-block identifier |
| `star` | -- | the star |
| `freq_lo_GHz` | GHz | lower window edge |
| `freq_hi_GHz` | GHz | upper window edge |
| `T_before` | -- | the search statistic of the earlier extraction |
| `T_rerun` | -- | the search statistic of the rerun |
| `rms_ratio` | -- | noise of the rerun over noise of the earlier extraction |
| `control_correlation` | -- | correlation of the two extractions' control-position statistics |

## `sensitivity/recombined_field_values.csv`

4 rows, 12 columns.

Proxima Cen: the stellar-frame stack over every epoch and the best single epoch, as the nominal five-sigma EIRP before the ninety-per-cent completeness factor, computed twice with one code: from the products the article uses, and with the windows of recalibrated blocks reading their recalibrated, field-recombined products. The recombined values are not used in the article: their completeness has not been re-verified by injection.

**Joins.** star joins stellar_sample.csv.

| column | unit | description |
|---|---|---|
| `star` | -- | the star |
| `band` | -- | ALMA band |
| `freq_lo_GHz` | GHz | lower edge of the common stellar-frame interval |
| `freq_hi_GHz` | GHz | upper edge of the common stellar-frame interval |
| `n_epochs` | -- | epochs stacked |
| `on_source_h` | h | on-source time, products the article uses |
| `on_source_h_recombined` | h | on-source time, recombined products |
| `eirp_stack_W` | W | nominal EIRP of the stack, products the article uses |
| `eirp_stack_recombined_W` | W | nominal EIRP of the stack, recombined products |
| `eirp_single_W` | W | nominal EIRP of the best single epoch, products the article uses |
| `eirp_single_recombined_W` | W | nominal EIRP of the best single epoch, recombined products |
| `completeness_verified` | -- | 1 if the completeness of these values was verified by injection |

## `figures/figure_data.csv`

7 rows, 14 columns.

The numerical data behind the figures that is in no other table here.

Most of the figures are drawn from columns deposited in this archive, and for those figure_sources.csv names the file and the columns rather than copying the numbers, so that a figure and the table behind it cannot disagree.

What is left is the external material the context figure compares the survey against: the deepest limit each published survey reports, the threshold it was set at, and the factor that puts it on a common threshold with this one. The note column gives the source of each value in the words of the paper it is taken from.

A rescaled limit is not that survey published number and is not attributable to its authors as such; it is this work rescaling of it, and the factor applied is beside it.

**Joins.** figure_sources.csv names, for every figure, the deposited file and columns it is drawn from.

| column | unit | description |
|---|---|---|
| `figure` | -- | the figure, named by what it shows rather than by a number, since numbering is a property of the typeset article |
| `panel` | -- | panel within it |
| `series` | -- | the series the point belongs to |
| `point` | -- | point index within the series |
| `x` | -- | abscissa |
| `x_quantity` | -- | what the abscissa is |
| `x_unit` | -- | its unit |
| `y` | -- | ordinate |
| `y_quantity` | -- | what the ordinate is |
| `y_unit` | -- | its unit |
| `y_rescaled` | -- | the ordinate rescaled to a common threshold, where the rescaling applies |
| `y_rescaled_quantity` | -- | what that rescaling is |
| `scale_factor` | -- | the factor applied |
| `note` | -- | the source of the value, quoted from the work it is taken from |

## `figures/figure_sources.csv`

11 rows, 5 columns.

One row per figure panel of the article: what it plots and which deposited columns it is plotted from.

Figures are named by what they show. A figure number is a property of the typeset article and would not survive a change of layout, so it is not used as an identifier here.

A panel whose data is not in any other deposited table has its series in figure_data.csv, and this table points there as well.

**Joins.** the file column names files in this archive and the columns column names their columns.

| column | unit | description |
|---|---|---|
| `figure` | -- | the figure, named by what it shows |
| `panel` | -- | panel within it, empty where there is one |
| `shows` | -- | what is plotted |
| `file` | -- | the deposited files the panel is drawn from, separated by semicolons |
| `columns` | -- | the columns within them, separated by semicolons |

## `statistics/article_values.csv`

73 rows, 5 columns.

The statistical and calibration summaries the article prints, with the deposited program that rebuilds each one from this archive and the quantity name that program prints. code/reproduce.py runs the programs and compares.

The tolerance is the article's own precision: a rebuilt quantity agrees when, written to the digits the article prints, it is the article's value. With the deposited seeds and the NumPy release the parameters files name, the Monte Carlo quantities are the same draws as the computation reported and agree exactly; with another seed they agree within the Monte Carlo error the programs print beside them.

**Joins.** program names a file of code/; reading is the field reading of the chance comparison and empty for the other programs

| column | unit | description |
|---|---|---|
| `program` | -- | the deposited program that rebuilds the quantity |
| `reading` | -- | whole_beam, narrow_field or both for the chance comparison; empty otherwise |
| `quantity` | -- | the quantity, named as the program prints it |
| `article_value` | -- | the value the article's build computes, as it prints it; a power of ten written as 1.8e15 |
| `in_text` | -- | 1 where the value is printed in the article text, 0 where it is computed with it but appears only here |

## `catalogues/block_sessions.csv`

501 rows, 6 columns.

One row per execution block named anywhere in this archive or processed by the search: its observing session and member observing unit, the groupings the block resampling and the separated-session rule act on.

session_id is the middle field of the ALMA block identifier (A002_<session>_<block>); two blocks are separated-session when their session_id differ. member_ous is the archive's member observing unit, several units joined by ; where the archive records more than one.

set_name is primary census for a block of execution_blocks.csv, reserved hold-out for a block of the sample held out by identifier, and other for a block read only as a repeat epoch or outside both sets.

**Joins.** eb joins every table carrying a block identifier.

| column | unit | description |
|---|---|---|
| `eb` | -- | ALMA execution block identifier |
| `session_id` | -- | the observing session, the middle field of the identifier |
| `member_ous` | -- | the archive member observing unit(s), without the uid:// prefix |
| `project_code` | -- | ALMA project code |
| `array` | -- | 12m or 7m where the archive records it |
| `set_name` | -- | primary census, reserved hold-out or other |

## The second file of this record: ALMA_Technosignatures_40pc_crossing_spectra.zip

The dynamic spectra at the star and at the retained control positions around each threshold crossing, one NumPy .npz file per crossing listed in its index.csv, with the SHA-256 of every member in its SHA256SUMS.

index.csv columns:

| column | unit | description |
|---|---|---|
| n | -- | row number, the crossing_NN of the file name |
| star | -- | star designation |
| eb | -- | ALMA execution block of the crossing |
| f_topo_GHz | GHz | topocentric crossing frequency |
| tstar | -- | the crossing statistic T_star |
| attributed | -- | True where the line mask attributes the crossing |
| source | -- | released: from the per-window catalogue; adopted list: from the crossing ledger |
| file | -- | path of the array file inside the zip |
| n_int | -- | integrations |
| n_chan | -- | channels in the stored crop |
| n_chan_window | -- | channels in the whole spectral window |
| drift_track_chan | -- | channels the fitted drift track crosses over the block |
| bytes | byte | size of the array file |
| reason | -- | why a crossing has no array file; empty where it has one |

Arrays of each .npz file. The extractor ran in three successive generations and a spectrum is cut from the product its crossing's statistic was read from: arrays marked 2 were first written by the second generation and arrays marked 3 by the final one, so a spectrum without extract_version comes from an earlier generation, the first if it also lacks dish_m.

| array | unit | from | description |
|---|---|---|---|
| I_star | Jy | 1 | [integration, channel] spectrum at the star, apparent flux density, the crop around the crossing |
| I_control_sample | Jy | 1 | [integration, position, channel] the same at the retained control positions |
| control_sample_names | -- | 1 | names of those control positions in the ensemble |
| W | -- | 1 | [integration, channel] visibility weight summed into each spectral point |
| times | s | 1 | integration mid-times, MJD seconds |
| freqs | Hz | 1 | topocentric channel frequencies of the crop |
| chanw | Hz | 1 | channel width |
| phase_ra | rad | 1 | phase-centre right ascension |
| phase_dec | rad | 1 | phase-centre declination |
| l_star | -- | 1 | direction cosine l of the star from the phase centre |
| m_star | -- | 1 | direction cosine m |
| pb_arcsec | arcsec | 1 | primary-beam FWHM used for the control annulus |
| dish_m | m | 2 | dish diameter read from the data |
| bmax_m | m | 2 | longest baseline |
| syn_arcsec | arcsec | 2 | synthesised-beam FWHM |
| ann_syn_factor | -- | 2 | inner edge of the control annulus in synthesised beams |
| star_name | -- | 1 | extraction target name |
| t1_ra | deg | 1 | barycentric right ascension of the star at the block epoch |
| t1_dec | deg | 1 | barycentric declination |
| parallax | mas | 1 | parallax used for the apparent position |
| parallax_err | mas | 1 | its uncertainty |
| expos | s | 3 | per-integration exposure |
| field_id | -- | 3 | per-integration field (pointing) identifier |
| pb_resp_rel | -- | 3 | per-integration relative primary-beam response at the star |
| on_source_s | s | 3 | on-source time, the sum of the exposures |
| ref_field | -- | 3 | the reference field of a multi-pointing block |
| n_fields | -- | 3 | fields combined |
| field_ids | -- | 3 | their identifiers |
| field_on_source_s | s | 3 | on-source time per field |
| field_offset_arcsec | arcsec | 3 | star offset from each field centre |
| field_pb_resp | -- | 3 | primary-beam response at the star in each field |
| extract_version | -- | 3 | label of the extractor that wrote the source product |
| pos_convention | -- | 3 | the position convention of the extraction |
| plx_dl_arcsec | arcsec | 3 | annual-parallax displacement in l |
| plx_dm_arcsec | arcsec | 3 | annual-parallax displacement in m |
| plx_offset_arcsec | arcsec | 3 | its magnitude |
| plx_offset_beams | -- | 3 | its magnitude in synthesised beams |
| plx_loss_gaussian | -- | 3 | amplitude a compact source keeps at that offset, Gaussian beam |
| l_bary_arcsec | arcsec | 3 | barycentric star offset in l |
| m_bary_arcsec | arcsec | 3 | barycentric star offset in m |
| l_app_arcsec | arcsec | 3 | apparent star offset in l |
| m_app_arcsec | arcsec | 3 | apparent star offset in m |
| crossing_eb | -- | 1 | execution block of the crossing |
| crossing_f_topo_GHz | GHz | 1 | its topocentric frequency |
| crossing_tstar | -- | 1 | its statistic |
| crossing_channel_in_crop | -- | 1 | its channel in the crop |
| crop_channels_of_window | -- | 1 | first and last window channel of the crop, and the window channel count |
| drift_max_Hz_s | Hz/s | 1 | largest drift rate searched in the window |
| source_product_sha256 | -- | 1 | SHA-256 of the extraction product the crop was cut from |
